@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">ট্রানজেকশন স্ট্যাটাস চেক</h4>
                </div>
                <div class="card-body">
                    <form action="{{ route('transactions.check-status') }}" method="POST" class="mb-4">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Sender Number <span class="text-danger">*</span></label>
                            <input type="text" 
                                class="form-control @error('sender_number') is-invalid @enderror" 
                                name="sender_number" 
                                value="{{ old('sender_number') }}"
                                placeholder="01XXXXXXXXX"
                                required>
                            @error('sender_number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Transaction ID (TrxID) <span class="text-danger">*</span></label>
                            <input type="text" 
                                class="form-control @error('transaction_id') is-invalid @enderror" 
                                name="transaction_id" 
                                value="{{ old('transaction_id') }}"
                                placeholder="8N7A6D5E"
                                required>
                            @error('transaction_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">স্ট্যাটাস চেক করুন</button>
                        </div>
                    </form>

                    @if(isset($transaction))
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">ট্রানজেকশন তথ্য</h5>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-2">
                                            <strong>প্যাকেজ:</strong><br>
                                            {{ $transaction->package->name }}
                                        </p>
                                        <p class="mb-2">
                                            <strong>মূল্য:</strong><br>
                                            ৳{{ number_format($transaction->amount, 2) }}
                                        </p>
                                        <p class="mb-2">
                                            <strong>সেন্ডার নম্বর:</strong><br>
                                            {{ $transaction->sender_number }}
                                        </p>
                                        <p class="mb-2">
                                            <strong>ট্রানজেকশন আইডি:</strong><br>
                                            {{ $transaction->transaction_id }}
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-2">
                                            <strong>স্ট্যাটাস:</strong><br>
                                            <span class="badge bg-{{ $transaction->status_color }} fs-6">
                                                @if($transaction->status === 'pending')
                                                    অপেক্ষমান
                                                @elseif($transaction->status === 'verified')
                                                    যাচাইকৃত
                                                @else
                                                    বাতিল
                                                @endif
                                            </span>
                                        </p>
                                        <p class="mb-2">
                                            <strong>সময়:</strong><br>
                                            {{ $transaction->created_at->format('d/m/Y H:i') }}
                                        </p>
                                        @if($transaction->status === 'verified')
                                            <p class="mb-2">
                                                <strong>WiFi ইউজারনেম:</strong><br>
                                                {{ $transaction->wifi_username }}
                                            </p>
                                            <p class="mb-2">
                                                <strong>WiFi পাসওয়ার্ড:</strong><br>
                                                {{ $transaction->wifi_password }}
                                            </p>
                                            <p class="mb-2">
                                                <strong>মেয়াদ শেষ:</strong><br>
                                                {{ $transaction->expires_at->format('d/m/Y H:i') }}
                                            </p>
                                        @endif
                                        @if($transaction->status === 'rejected')
                                            <p class="mb-2">
                                                <strong>বাতিলের কারণ:</strong><br>
                                                {{ $transaction->admin_note }}
                                            </p>
                                        @endif
                                    </div>
                                </div>

                                @if($transaction->status === 'verified')
                                    <div class="alert alert-success mt-3">
                                        <h6 class="alert-heading">WiFi ব্যবহার নির্দেশনা:</h6>
                                        <ol class="mb-0">
                                            <li>WiFi সেটিংস-এ যান</li>
                                            <li>হটস্পট নেটওয়ার্ক সিলেক্ট করুন</li>
                                            <li>উপরে দেওয়া ইউজারনেম এবং পাসওয়ার্ড ব্যবহার করুন</li>
                                            <li>ইন্টারনেট ব্যবহার শুরু করুন</li>
                                        </ol>
                                    </div>
                                @endif

                                @if($transaction->status === 'pending')
                                    <div class="alert alert-info mt-3">
                                        <i class="fas fa-info-circle me-2"></i>
                                        আপনার পেমেন্ট যাচাই প্রক্রিয়াধীন আছে। যাচাই হওয়ার পর WiFi ক্রেডেনশিয়ালস দেখতে পাবেন।
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@if(isset($transaction) && $transaction->status === 'pending')
    @push('scripts')
    <script>
        // Auto-refresh status every 30 seconds for pending transactions
        setInterval(function() {
            window.location.reload();
        }, 30000);
    </script>
    @endpush
@endif

@endsection