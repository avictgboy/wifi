<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Submitted - WiFi Billing System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div class="text-center">
                <svg class="mx-auto h-12 w-12 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                    Payment Submitted Successfully!
                </h2>
                <p class="mt-2 text-center text-sm text-gray-600">
                    Your payment is being processed. Please wait for confirmation.
                </p>
            </div>

            @if(session('transaction'))
                <div class="mt-8 bg-white overflow-hidden shadow rounded-lg">
                    <div class="px-4 py-5 sm:p-6">
                        <dl class="space-y-4">
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Transaction ID</dt>
                                <dd class="mt-1 text-sm text-gray-900">{{ session('transaction')->trx_id }}</dd>
                            </div>

                            <div>
                                <dt class="text-sm font-medium text-gray-500">Package</dt>
                                <dd class="mt-1 text-sm text-gray-900">{{ session('transaction')->package->name }}</dd>
                            </div>

                            <div>
                                <dt class="text-sm font-medium text-gray-500">Amount</dt>
                                <dd class="mt-1 text-sm text-gray-900">{{ number_format(session('transaction')->amount, 2) }} TK</dd>
                            </div>

                            <div>
                                <dt class="text-sm font-medium text-gray-500">Status</dt>
                                <dd class="mt-1 text-sm text-gray-900" id="status-text">Pending Verification</dd>
                            </div>

                            <div id="credentials-section" class="hidden">
                                <dt class="text-sm font-medium text-gray-500">WiFi Credentials</dt>
                                <dd class="mt-1 text-sm text-gray-900">
                                    <div class="bg-gray-50 rounded p-3">
                                        <p><strong>Username:</strong> <span id="wifi-username"></span></p>
                                        <p><strong>Password:</strong> <span id="wifi-password"></span></p>
                                        <p><strong>Valid Until:</strong> <span id="expires-at"></span></p>
                                    </div>
                                </dd>
                            </div>
                        </dl>
                    </div>
                </div>

                <div class="mt-4 text-center text-sm text-gray-600">
                    <p>You will receive an SMS with your WiFi credentials once the payment is verified.</p>
                    <p class="mt-2">This page will automatically update when your payment is verified.</p>
                </div>

                <script>
                    function checkStatus() {
                        fetch('{{ route("transactions.check-status", session("transaction")) }}')
                            .then(response => response.json())
                            .then(data => {
                                const statusText = document.getElementById('status-text');
                                const credentialsSection = document.getElementById('credentials-section');

                                if (data.status === 'verified') {
                                    statusText.textContent = 'Payment Verified';
                                    statusText.className = 'mt-1 text-sm text-green-600 font-medium';
                                    
                                    // Show credentials
                                    document.getElementById('wifi-username').textContent = data.wifi_username;
                                    document.getElementById('wifi-password').textContent = data.wifi_password;
                                    document.getElementById('expires-at').textContent = new Date(data.expires_at).toLocaleString();
                                    credentialsSection.classList.remove('hidden');
                                    
                                    // Stop polling
                                    clearInterval(statusInterval);
                                } else if (data.status === 'rejected') {
                                    statusText.textContent = 'Payment Rejected: ' + data.message;
                                    statusText.className = 'mt-1 text-sm text-red-600 font-medium';
                                    clearInterval(statusInterval);
                                }
                            })
                            .catch(error => console.error('Error:', error));
                    }

                    // Check status every 10 seconds
                    const statusInterval = setInterval(checkStatus, 10000);
                    
                    // Check immediately on page load
                    checkStatus();
                </script>
            @endif

            <div class="mt-8">
                <a href="{{ route('transactions.create') }}" class="text-indigo-600 hover:text-indigo-500 text-sm font-medium">
                    ← Back to Package Selection
                </a>
            </div>
        </div>
    </div>
</body>
</html>