<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy WiFi Package</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen py-6">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                <div class="px-4 py-5 sm:p-6">
                    <h1 class="text-2xl font-bold text-gray-900 text-center mb-8">Buy WiFi Package</h1>

                    @if ($errors->any())
                        <div class="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                                    </svg>
                                </div>
                                <div class="ml-3">
                                    <h3 class="text-sm leading-5 font-medium text-red-800">There were errors with your submission</h3>
                                    <ul class="mt-2 text-sm text-red-700">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- Package Selection -->
                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-8">
                        @foreach($packages as $package)
                            <div class="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm flex flex-col items-center space-y-3 hover:border-gray-400 cursor-pointer package-card"
                                 data-package-id="{{ $package->id }}"
                                 data-package-price="{{ $package->price }}">
                                <div class="text-lg font-medium text-gray-900">{{ $package->name }}</div>
                                <div class="text-2xl font-bold text-indigo-600">{{ $package->formatted_price }}</div>
                                <div class="text-sm text-gray-500">{{ $package->formatted_duration }}</div>
                                @if($package->description)
                                    <div class="text-xs text-gray-500 text-center">{{ $package->description }}</div>
                                @endif
                            </div>
                        @endforeach
                    </div>

                    <!-- Payment Form -->
                    <form action="{{ route('transactions.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                        @csrf
                        <input type="hidden" name="package_id" id="selected_package_id">

                        <div class="bg-gray-50 p-6 rounded-lg">
                            <h2 class="text-lg font-medium text-gray-900 mb-4">Payment Instructions</h2>
                            <ol class="list-decimal list-inside space-y-2 text-gray-600">
                                <li>Send money to our bKash number: <span class="font-medium">01XXXXXXXXX</span></li>
                                <li>Use "Send Money" option (not "Make Payment")</li>
                                <li>Keep the Transaction ID (TrxID) from the confirmation message</li>
                                <li>Fill out the form below with your payment details</li>
                            </ol>
                        </div>

                        <div class="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                            <div class="sm:col-span-2">
                                <label for="sender_number" class="block text-sm font-medium text-gray-700">bKash Number (Sender)</label>
                                <div class="mt-1">
                                    <input type="text" name="sender_number" id="sender_number" required
                                           class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                           placeholder="01XXXXXXXXX">
                                </div>
                            </div>

                            <div>
                                <label for="amount" class="block text-sm font-medium text-gray-700">Amount</label>
                                <div class="mt-1">
                                    <input type="number" name="amount" id="amount" required readonly
                                           class="bg-gray-50 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md">
                                </div>
                            </div>

                            <div>
                                <label for="trx_id" class="block text-sm font-medium text-gray-700">Transaction ID (TrxID)</label>
                                <div class="mt-1">
                                    <input type="text" name="trx_id" id="trx_id" required
                                           class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                           placeholder="AB7CDEFGHI">
                                </div>
                            </div>

                            <div class="sm:col-span-2">
                                <label for="screenshot" class="block text-sm font-medium text-gray-700">Payment Screenshot (Optional)</label>
                                <div class="mt-1">
                                    <input type="file" name="screenshot" id="screenshot"
                                           class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300">
                                </div>
                                <p class="mt-2 text-sm text-gray-500">Upload a screenshot of your payment confirmation message (Max 2MB)</p>
                            </div>
                        </div>

                        <div class="pt-5">
                            <button type="submit"
                                    class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                Submit Payment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const packageCards = document.querySelectorAll('.package-card');
            const selectedPackageInput = document.getElementById('selected_package_id');
            const amountInput = document.getElementById('amount');

            packageCards.forEach(card => {
                card.addEventListener('click', function() {
                    // Remove active class from all cards
                    packageCards.forEach(c => c.classList.remove('ring-2', 'ring-indigo-500'));
                    
                    // Add active class to selected card
                    this.classList.add('ring-2', 'ring-indigo-500');
                    
                    // Update hidden inputs
                    selectedPackageInput.value = this.dataset.packageId;
                    amountInput.value = this.dataset.packagePrice;
                });
            });
        });
    </script>
</body>
</html>