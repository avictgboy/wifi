@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4">
    <h1 class="mt-4">সিস্টেম সেটিংস</h1>

    <div class="row">
        <div class="col-xl-8">
            <!-- General Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-cog me-1"></i>
                    সাধারণ সেটিংস
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.settings.update') }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label class="form-label">সিস্টেমের নাম</label>
                            <input type="text" 
                                class="form-control @error('app_name') is-invalid @enderror" 
                                name="app_name" 
                                value="{{ old('app_name', config('app.name')) }}">
                            @error('app_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">যোগাযোগের ফোন নম্বর</label>
                            <input type="text" 
                                class="form-control @error('contact_phone') is-invalid @enderror" 
                                name="contact_phone" 
                                value="{{ old('contact_phone', config('app.contact_phone')) }}">
                            @error('contact_phone')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">যোগাযোগের ইমেইল</label>
                            <input type="email" 
                                class="form-control @error('contact_email') is-invalid @enderror" 
                                name="contact_email" 
                                value="{{ old('contact_email', config('app.contact_email')) }}">
                            @error('contact_email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary">সেটিংস আপডেট করুন</button>
                    </form>
                </div>
            </div>

            <!-- MikroTik Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-network-wired me-1"></i>
                    MikroTik সেটিংস
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.settings.update-mikrotik') }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label class="form-label">রাউটার IP/হোস্ট</label>
                            <input type="text" 
                                class="form-control @error('mikrotik_host') is-invalid @enderror" 
                                name="mikrotik_host" 
                                value="{{ old('mikrotik_host', config('mikrotik.host')) }}">
                            @error('mikrotik_host')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">API ইউজারনেম</label>
                            <input type="text" 
                                class="form-control @error('mikrotik_user') is-invalid @enderror" 
                                name="mikrotik_user" 
                                value="{{ old('mikrotik_user', config('mikrotik.user')) }}">
                            @error('mikrotik_user')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">API পাসওয়ার্ড</label>
                            <input type="password" 
                                class="form-control @error('mikrotik_password') is-invalid @enderror" 
                                name="mikrotik_password" 
                                placeholder="পাসওয়ার্ড পরিবর্তন করতে নতুন পাসওয়ার্ড দিন">
                            @error('mikrotik_password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">API পোর্ট</label>
                            <input type="number" 
                                class="form-control @error('mikrotik_port') is-invalid @enderror" 
                                name="mikrotik_port" 
                                value="{{ old('mikrotik_port', config('mikrotik.port')) }}">
                            @error('mikrotik_port')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">ডিফল্ট হটস্পট প্রোফাইল</label>
                            <input type="text" 
                                class="form-control @error('mikrotik_default_profile') is-invalid @enderror" 
                                name="mikrotik_default_profile" 
                                value="{{ old('mikrotik_default_profile', config('mikrotik.default_profile')) }}">
                            @error('mikrotik_default_profile')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary">MikroTik সেটিংস আপডেট করুন</button>
                    </form>
                </div>
            </div>

            <!-- SMS Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-sms me-1"></i>
                    SMS সেটিংস
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.settings.update-sms') }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label class="form-label">SMS API কী</label>
                            <input type="text" 
                                class="form-control @error('sms_api_key') is-invalid @enderror" 
                                name="sms_api_key" 
                                value="{{ old('sms_api_key', config('services.sms.api_key')) }}">
                            @error('sms_api_key')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">সেন্ডার আইডি</label>
                            <input type="text" 
                                class="form-control @error('sms_sender_id') is-invalid @enderror" 
                                name="sms_sender_id" 
                                value="{{ old('sms_sender_id', config('services.sms.sender_id')) }}">
                            @error('sms_sender_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary">SMS সেটিংস আপডেট করুন</button>
                    </form>
                </div>
            </div>

            <!-- bKash Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-money-bill me-1"></i>
                    bKash সেটিংস
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.settings.update-bkash') }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label class="form-label">মার্চেন্ট নম্বর</label>
                            <input type="text" 
                                class="form-control @error('bkash_merchant_number') is-invalid @enderror" 
                                name="bkash_merchant_number" 
                                value="{{ old('bkash_merchant_number', config('services.bkash.merchant_number')) }}">
                            @error('bkash_merchant_number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">API কী</label>
                            <input type="text" 
                                class="form-control @error('bkash_api_key') is-invalid @enderror" 
                                name="bkash_api_key" 
                                value="{{ old('bkash_api_key', config('services.bkash.api_key')) }}">
                            @error('bkash_api_key')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">API সিক্রেট</label>
                            <input type="password" 
                                class="form-control @error('bkash_api_secret') is-invalid @enderror" 
                                name="bkash_api_secret" 
                                placeholder="সিক্রেট পরিবর্তন করতে নতুন সিক্রেট দিন">
                            @error('bkash_api_secret')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">ইউজারনেম</label>
                            <input type="text" 
                                class="form-control @error('bkash_username') is-invalid @enderror" 
                                name="bkash_username" 
                                value="{{ old('bkash_username', config('services.bkash.username')) }}">
                            @error('bkash_username')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">পাসওয়ার্ড</label>
                            <input type="password" 
                                class="form-control @error('bkash_password') is-invalid @enderror" 
                                name="bkash_password" 
                                placeholder="পাসওয়ার্ড পরিবর্তন করতে নতুন পাসওয়ার্ড দিন">
                            @error('bkash_password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" 
                                    class="form-check-input" 
                                    name="bkash_sandbox" 
                                    id="bkash_sandbox"
                                    value="1" 
                                    {{ config('services.bkash.sandbox') ? 'checked' : '' }}>
                                <label class="form-check-label" for="bkash_sandbox">
                                    স্যান্ডবক্স মোড (টেস্টিং এর জন্য)
                                </label>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">bKash সেটিংস আপডেট করুন</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <!-- Test Connection Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-plug me-1"></i>
                    কানেকশন টেস্ট
                </div>
                <div class="card-body">
                    <!-- MikroTik Test -->
                    <div class="mb-4">
                        <h6>MikroTik কানেকশন</h6>
                        <button type="button" 
                            class="btn btn-outline-primary btn-sm" 
                            onclick="testMikrotikConnection()">
                            <i class="fas fa-network-wired me-1"></i> টেস্ট করুন
                        </button>
                        <div id="mikrotikTestResult" class="mt-2"></div>
                    </div>

                    <!-- SMS Test -->
                    <div class="mb-4">
                        <h6>SMS কানেকশন</h6>
                        <div class="input-group input-group-sm mb-2">
                            <input type="text" 
                                class="form-control" 
                                id="testSmsNumber" 
                                placeholder="টেস্ট SMS এর জন্য নম্বর দিন">
                            <button class="btn btn-outline-primary" 
                                type="button"
                                onclick="testSmsConnection()">
                                <i class="fas fa-sms me-1"></i> টেস্ট করুন
                            </button>
                        </div>
                        <div id="smsTestResult"></div>
                    </div>

                    <!-- bKash Test -->
                    <div class="mb-4">
                        <h6>bKash কানেকশন</h6>
                        <button type="button" 
                            class="btn btn-outline-primary btn-sm" 
                            onclick="testBkashConnection()">
                            <i class="fas fa-money-bill me-1"></i> টেস্ট করুন
                        </button>
                        <div id="bkashTestResult" class="mt-2"></div>
                    </div>
                </div>
            </div>

            <!-- System Info Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-info-circle me-1"></i>
                    সিস্টেম তথ্য
                </div>
                <div class="card-body">
                    <p class="mb-2">
                        <strong>লারাভেল ভার্সন:</strong><br>
                        {{ app()->version() }}
                    </p>
                    <p class="mb-2">
                        <strong>PHP ভার্সন:</strong><br>
                        {{ phpversion() }}
                    </p>
                    <p class="mb-2">
                        <strong>সর্বশেষ আপডেট:</strong><br>
                        {{ \Carbon\Carbon::parse(config('app.last_updated'))->format('d/m/Y H:i') }}
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function showTestResult(elementId, success, message) {
    const element = document.getElementById(elementId);
    element.innerHTML = `
        <div class="alert alert-${success ? 'success' : 'danger'} alert-dismissible fade show py-2 mt-2 mb-0" role="alert">
            <small>${message}</small>
            <button type="button" class="btn-close p-2" data-bs-dismiss="alert"></button>
        </div>
    `;
}

function testMikrotikConnection() {
    axios.post('{{ route("admin.settings.test-mikrotik") }}')
        .then(response => {
            showTestResult('mikrotikTestResult', true, 'MikroTik কানেকশন সফল হয়েছে!');
        })
        .catch(error => {
            showTestResult('mikrotikTestResult', false, 'MikroTik কানেকশন ব্যর্থ হয়েছে। সেটিংস চেক করুন।');
        });
}

function testSmsConnection() {
    const number = document.getElementById('testSmsNumber').value;
    if (!number) {
        showTestResult('smsTestResult', false, 'দয়া করে একটি ফোন নম্বর দিন।');
        return;
    }

    axios.post('{{ route("admin.settings.test-sms") }}', { number })
        .then(response => {
            showTestResult('smsTestResult', true, 'টেস্ট SMS পাঠানো হয়েছে!');
        })
        .catch(error => {
            showTestResult('smsTestResult', false, 'SMS পাঠাতে ব্যর্থ হয়েছে। সেটিংস চেক করুন।');
        });
}

function testBkashConnection() {
    axios.post('{{ route("admin.settings.test-bkash") }}')
        .then(response => {
            showTestResult('bkashTestResult', true, 'bKash API কানেকশন সফল হয়েছে!');
        })
        .catch(error => {
            showTestResult('bkashTestResult', false, 'bKash API কানেকশন ব্যর্থ হয়েছে। সেটিংস চেক করুন।');
        });
}
</script>
@endpush
@endsection