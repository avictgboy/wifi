<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\PackageController;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Route;

// Public routes
Route::get('/', function () {
    return redirect()->route('transactions.create');
});

Route::get('/buy', [TransactionController::class, 'create'])->name('transactions.create');
Route::post('/buy', [TransactionController::class, 'store'])->name('transactions.store');
Route::get('/success', [TransactionController::class, 'success'])->name('transactions.success');
Route::get('/check-status/{transaction}', [TransactionController::class, 'checkStatus'])
    ->name('transactions.check-status');

// Admin routes
Route::prefix('admin')->middleware(['auth'])->name('admin.')->group(function () {
    // Dashboard
    Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');
    
    // Packages management
    Route::get('/packages', [PackageController::class, 'index'])->name('packages.index');
    Route::get('/packages/create', [PackageController::class, 'create'])->name('packages.create');
    Route::post('/packages', [PackageController::class, 'store'])->name('packages.store');
    Route::get('/packages/{package}/edit', [PackageController::class, 'edit'])->name('packages.edit');
    Route::put('/packages/{package}', [PackageController::class, 'update'])->name('packages.update');
    Route::delete('/packages/{package}', [PackageController::class, 'destroy'])->name('packages.destroy');
    Route::post('/packages/{package}/toggle', [PackageController::class, 'toggle'])->name('packages.toggle');
    Route::get('/packages/report', [PackageController::class, 'report'])->name('packages.report');

    // Transactions management
    Route::get('/transactions', [AdminController::class, 'transactions'])->name('transactions.index');
    Route::post('/transactions/{transaction}/verify', [TransactionController::class, 'verifyPayment'])
        ->name('transactions.verify');
    Route::post('/transactions/{transaction}/reject', [TransactionController::class, 'rejectPayment'])
        ->name('transactions.reject');

    // Reports
    Route::get('/reports', [AdminController::class, 'reports'])->name('reports');

    // Settings
    Route::get('/settings', [AdminController::class, 'settings'])->name('settings');
    Route::post('/settings', [AdminController::class, 'updateSettings'])->name('settings.update');
});

// Authentication routes
require __DIR__.'/auth.php';