<?php

return [
    /*
    |--------------------------------------------------------------------------
    | MikroTik Connection Settings
    |--------------------------------------------------------------------------
    |
    | These settings are used to connect to your MikroTik router via API.
    | Make sure to use secure credentials and restrict API access.
    |
    */

    'host' => env('MIKROTIK_HOST', '192.168.1.1'),
    'user' => env('MIKROTIK_USER', 'admin'),
    'password' => env('MIKROTIK_PASSWORD', ''),
    'port' => env('MIKROTIK_PORT', 8728),

    /*
    |--------------------------------------------------------------------------
    | Default Hotspot Settings
    |--------------------------------------------------------------------------
    |
    | These settings define the default configuration for new hotspot users.
    |
    */

    'default_profile' => 'default',
    'default_server' => 'all',

    /*
    |--------------------------------------------------------------------------
    | User Profile Settings
    |--------------------------------------------------------------------------
    |
    | Define different user profiles with their respective settings.
    | These profiles should match your MikroTik hotspot user profiles.
    |
    */

    'profiles' => [
        'default' => [
            'rate_limit' => '1M/1M',
            'shared_users' => 1,
            'keepalive_timeout' => '2m',
            'status_autorefresh' => '1m',
        ],
        
        'premium' => [
            'rate_limit' => '2M/2M',
            'shared_users' => 1,
            'keepalive_timeout' => '2m',
            'status_autorefresh' => '1m',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | API Connection Settings
    |--------------------------------------------------------------------------
    |
    | Configure API connection behavior and timeouts.
    |
    */

    'timeout' => 10,
    'attempts' => 3,
    'delay_between_attempts' => 1,

    /*
    |--------------------------------------------------------------------------
    | Debug Mode
    |--------------------------------------------------------------------------
    |
    | When enabled, additional information will be logged about API operations.
    |
    */

    'debug' => env('MIKROTIK_DEBUG', false),
];