<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as SMS, Payment Gateways, and others. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'sms' => [
        'api_key' => env('SMS_API_KEY'),
        'sender_id' => env('SMS_SENDER_ID'),
        'debug' => env('SMS_DEBUG', false),
        'timeout' => env('SMS_TIMEOUT', 10),
    ],

    'bkash' => [
        'api_key' => env('BKASH_API_KEY'),
        'api_secret' => env('BKASH_API_SECRET'),
        'username' => env('BKASH_USERNAME'),
        'password' => env('BKASH_PASSWORD'),
        'sandbox' => env('BKASH_SANDBOX', true),
    ],

    'mikrotik' => [
        'host' => env('MIKROTIK_HOST'),
        'user' => env('MIKROTIK_USER'),
        'password' => env('MIKROTIK_PASSWORD'),
        'port' => env('MIKROTIK_PORT'),
    ],
];