<?php

namespace App\Http\Controllers;

use App\Models\Package;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    public function index()
    {
        $packages = Package::orderBy('duration_days')->get();
        return view('admin.packages.index', compact('packages'));
    }

    public function create()
    {
        return view('admin.packages.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'duration_days' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'is_active' => 'boolean'
        ]);

        Package::create($validated);

        return redirect()
            ->route('admin.packages.index')
            ->with('success', 'Package created successfully');
    }

    public function edit(Package $package)
    {
        return view('admin.packages.edit', compact('package'));
    }

    public function update(Request $request, Package $package)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'duration_days' => 'required|integer|min:1',
            'price' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'is_active' => 'boolean'
        ]);

        $package->update($validated);

        return redirect()
            ->route('admin.packages.index')
            ->with('success', 'Package updated successfully');
    }

    public function destroy(Package $package)
    {
        if ($package->transactions()->exists()) {
            return redirect()
                ->route('admin.packages.index')
                ->with('error', 'Cannot delete package with existing transactions');
        }

        $package->delete();

        return redirect()
            ->route('admin.packages.index')
            ->with('success', 'Package deleted successfully');
    }

    public function toggle(Package $package)
    {
        $package->is_active = !$package->is_active;
        $package->save();

        return redirect()
            ->route('admin.packages.index')
            ->with('success', 'Package status updated successfully');
    }

    public function report()
    {
        $packages = Package::withCount(['transactions' => function($query) {
            $query->where('status', 'verified');
        }])->withSum(['transactions' => function($query) {
            $query->where('status', 'verified');
        }], 'amount')
        ->get()
        ->map(function($package) {
            $package->total_revenue = $package->transactions_sum_amount ?? 0;
            return $package;
        });

        return view('admin.packages.report', compact('packages'));
    }
}