<?php

namespace App\Http\Controllers;

use App\Models\Package;
use App\Models\Transaction;
use App\Services\MikrotikService;
use App\Services\SmsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TransactionController extends Controller
{
    private MikrotikService $mikrotikService;
    private SmsService $smsService;

    public function __construct(MikrotikService $mikrotikService, SmsService $smsService)
    {
        $this->mikrotikService = $mikrotikService;
        $this->smsService = $smsService;
    }

    public function create()
    {
        $packages = Package::where('is_active', true)->get();
        return view('transactions.create', compact('packages'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'package_id' => 'required|exists:packages,id',
            'sender_number' => 'required|regex:/^01[3-9]\d{8}$/',
            'amount' => 'required|numeric|min:1',
            'trx_id' => 'required|unique:transactions,trx_id',
            'screenshot' => 'nullable|image|max:2048'
        ]);

        $package = Package::findOrFail($validated['package_id']);
        
        if ($package->price != $validated['amount']) {
            return back()->withErrors(['amount' => 'Invalid amount for selected package']);
        }

        $transaction = new Transaction($validated);

        if ($request->hasFile('screenshot')) {
            $path = $request->file('screenshot')->store('screenshots', 'public');
            $transaction->screenshot_path = $path;
        }

        $transaction->save();
        $this->smsService->sendPaymentConfirmation($transaction);

        return redirect()->route('transactions.success')->with('transaction', $transaction);
    }

    public function verifyPayment(Transaction $transaction)
    {
        $transaction->generateWifiCredentials();
        $transaction->markAsVerified();

        if ($this->mikrotikService->createHotspotUser($transaction)) {
            $this->smsService->sendWifiCredentials($transaction);
            return redirect()->back()->with('success', 'Payment verified and WiFi credentials sent');
        }

        return redirect()->back()->with('error', 'Failed to create hotspot user');
    }

    public function rejectPayment(Request $request, Transaction $transaction)
    {
        $validated = $request->validate([
            'admin_note' => 'required|string|max:255'
        ]);

        $transaction->admin_note = $validated['admin_note'];
        $transaction->markAsRejected();
        $this->smsService->sendPaymentRejection($transaction);

        return redirect()->back()->with('success', 'Payment rejected and customer notified');
    }

    public function success()
    {
        return view('transactions.success');
    }

    public function checkStatus(Transaction $transaction)
    {
        if ($transaction->status === 'verified') {
            $userStatus = $this->mikrotikService->getUserStatus($transaction->wifi_username);
            return response()->json([
                'status' => $transaction->status,
                'wifi_username' => $transaction->wifi_username,
                'wifi_password' => $transaction->wifi_password,
                'expires_at' => $transaction->expires_at,
                'mikrotik_status' => $userStatus
            ]);
        }

        return response()->json([
            'status' => $transaction->status,
            'message' => $transaction->admin_note
        ]);
    }
}