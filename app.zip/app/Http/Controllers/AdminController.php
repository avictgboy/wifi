<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Package;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'total_revenue' => Transaction::where('status', 'verified')
                ->sum('amount'),
            'today_revenue' => Transaction::where('status', 'verified')
                ->whereDate('created_at', today())
                ->sum('amount'),
            'pending_transactions' => Transaction::where('status', 'pending')
                ->count(),
            'active_users' => Transaction::where('status', 'verified')
                ->where('expires_at', '>', now())
                ->count()
        ];

        $recent_transactions = Transaction::with('package')
            ->latest()
            ->take(10)
            ->get();

        return view('admin.dashboard', compact('stats', 'recent_transactions'));
    }

    public function transactions(Request $request)
    {
        $query = Transaction::with('package')
            ->when($request->status, function($q, $status) {
                return $q->where('status', $status);
            })
            ->when($request->package_id, function($q, $package_id) {
                return $q->where('package_id', $package_id);
            })
            ->when($request->date_range, function($q, $date_range) {
                $dates = explode(' - ', $date_range);
                return $q->whereBetween('created_at', $dates);
            })
            ->when($request->search, function($q, $search) {
                return $q->where(function($query) use ($search) {
                    $query->where('sender_number', 'like', "%{$search}%")
                          ->orWhere('trx_id', 'like', "%{$search}%")
                          ->orWhere('wifi_username', 'like', "%{$search}%");
                });
            });

        $transactions = $query->latest()->paginate(20);
        $packages = Package::all();

        return view('admin.transactions.index', compact('transactions', 'packages'));
    }

    public function reports(Request $request)
    {
        $start_date = $request->start_date ?? now()->startOfMonth();
        $end_date = $request->end_date ?? now();

        $daily_revenue = Transaction::where('status', 'verified')
            ->whereBetween('created_at', [$start_date, $end_date])
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as total_transactions'),
                DB::raw('SUM(amount) as total_amount')
            )
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $package_stats = Package::withCount([
            'transactions' => function($query) use ($start_date, $end_date) {
                $query->where('status', 'verified')
                      ->whereBetween('created_at', [$start_date, $end_date]);
            }
        ])->withSum([
            'transactions' => function($query) use ($start_date, $end_date) {
                $query->where('status', 'verified')
                      ->whereBetween('created_at', [$start_date, $end_date]);
            }
        ], 'amount')
        ->get();

        return view('admin.reports', compact(
            'daily_revenue',
            'package_stats',
            'start_date',
            'end_date'
        ));
    }

    public function settings()
    {
        return view('admin.settings');
    }

    public function updateSettings(Request $request)
    {
        $validated = $request->validate([
            'mikrotik_host' => 'required|string',
            'mikrotik_user' => 'required|string',
            'mikrotik_password' => 'required|string',
            'mikrotik_port' => 'required|integer',
            'bkash_api_key' => 'required|string',
            'bkash_api_secret' => 'required|string',
            'sms_api_key' => 'required|string',
            'sms_sender_id' => 'required|string',
        ]);

        foreach ($validated as $key => $value) {
            config(['services.' . $key => $value]);
        }

        return redirect()
            ->back()
            ->with('success', 'Settings updated successfully');
    }
}