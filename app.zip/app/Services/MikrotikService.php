<?php

namespace App\Services;

use App\Models\Transaction;
use Exception;
use RouterOS\Client;
use RouterOS\Config;
use RouterOS\Query;

class MikrotikService
{
    private Client $client;

    public function __construct()
    {
        $config = new Config([
            'host' => config('mikrotik.host'),
            'user' => config('mikrotik.user'),
            'pass' => config('mikrotik.password'),
            'port' => config('mikrotik.port')
        ]);

        $this->client = new Client($config);
    }

    public function createHotspotUser(Transaction $transaction): bool
    {
        try {
            $query = new Query('/ip/hotspot/user/add');
            $query->equal('name', $transaction->wifi_username)
                  ->equal('password', $transaction->wifi_password)
                  ->equal('profile', 'default')
                  ->equal('limit-uptime', $transaction->package->duration_days . 'd 00:00:00');

            $this->client->query($query)->read();

            return true;
        } catch (Exception $e) {
            report($e);
            return false;
        }
    }

    public function removeHotspotUser(string $username): bool
    {
        try {
            $query = new Query('/ip/hotspot/user/remove');
            $query->where('name', $username);

            $this->client->query($query)->read();

            return true;
        } catch (Exception $e) {
            report($e);
            return false;
        }
    }

    public function getUserStatus(string $username): array
    {
        try {
            $query = new Query('/ip/hotspot/user/print');
            $query->where('name', $username);

            $response = $this->client->query($query)->read();

            return $response[0] ?? [];
        } catch (Exception $e) {
            report($e);
            return [];
        }
    }

    public function updateUserProfile(string $username, string $profile): bool
    {
        try {
            $query = new Query('/ip/hotspot/user/set');
            $query->where('name', $username)
                  ->equal('profile', $profile);

            $this->client->query($query)->read();

            return true;
        } catch (Exception $e) {
            report($e);
            return false;
        }
    }
}