<?php

namespace App\Services;

use App\Models\Transaction;
use Illuminate\Support\Facades\Http;
use Exception;

class SmsService
{
    private string $apiKey;
    private string $senderId;
    private string $apiUrl;

    public function __construct()
    {
        $this->apiKey = config('services.sms.api_key');
        $this->senderId = config('services.sms.sender_id');
        $this->apiUrl = 'https://api.sms-gateway.com/send'; // Replace with actual SMS gateway URL
    }

    public function sendWifiCredentials(Transaction $transaction): bool
    {
        try {
            $message = sprintf(
                'Your WiFi access credentials:\nUsername: %s\nPassword: %s\nValid until: %s\nThank you for choosing our service!',
                $transaction->wifi_username,
                $transaction->wifi_password,
                $transaction->expires_at->format('d M Y H:i')
            );

            $response = Http::post($this->apiUrl, [
                'api_key' => $this->apiKey,
                'sender_id' => $this->senderId,
                'phone' => $transaction->sender_number,
                'message' => $message
            ]);

            if ($response->successful()) {
                return true;
            }

            report(new Exception('SMS sending failed: ' . $response->body()));
            return false;

        } catch (Exception $e) {
            report($e);
            return false;
        }
    }

    public function sendPaymentConfirmation(Transaction $transaction): bool
    {
        try {
            $message = sprintf(
                'Payment received! Amount: %s TK\nTransaction ID: %s\nPackage: %s\nStatus: Processing\nYou will receive WiFi credentials shortly.',
                number_format($transaction->amount, 2),
                $transaction->trx_id,
                $transaction->package->name
            );

            $response = Http::post($this->apiUrl, [
                'api_key' => $this->apiKey,
                'sender_id' => $this->senderId,
                'phone' => $transaction->sender_number,
                'message' => $message
            ]);

            return $response->successful();

        } catch (Exception $e) {
            report($e);
            return false;
        }
    }

    public function sendPaymentRejection(Transaction $transaction): bool
    {
        try {
            $message = sprintf(
                'Payment rejected for Transaction ID: %s\nReason: %s\nPlease contact support for assistance.',
                $transaction->trx_id,
                $transaction->admin_note ?? 'Invalid payment information'
            );

            $response = Http::post($this->apiUrl, [
                'api_key' => $this->apiKey,
                'sender_id' => $this->senderId,
                'phone' => $transaction->sender_number,
                'message' => $message
            ]);

            return $response->successful();

        } catch (Exception $e) {
            report($e);
            return false;
        }
    }
}