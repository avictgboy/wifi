<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Transaction extends Model
{
    protected $fillable = [
        'package_id',
        'sender_number',
        'amount',
        'trx_id',
        'screenshot_path',
        'status',
        'wifi_username',
        'wifi_password',
        'verified_at',
        'expires_at',
        'admin_note'
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'verified_at' => 'datetime',
        'expires_at' => 'datetime'
    ];

    public function package(): BelongsTo
    {
        return $this->belongsTo(Package::class);
    }

    public function markAsVerified(): void
    {
        $this->status = 'verified';
        $this->verified_at = now();
        $this->expires_at = now()->addDays($this->package->duration_days);
        $this->save();
    }

    public function markAsRejected(): void
    {
        $this->status = 'rejected';
        $this->save();
    }

    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    public function generateWifiCredentials(): void
    {
        $this->wifi_username = 'user_' . strtolower(substr(md5(uniqid()), 0, 8));
        $this->wifi_password = strtolower(substr(md5(uniqid()), 0, 8));
        $this->save();
    }
}